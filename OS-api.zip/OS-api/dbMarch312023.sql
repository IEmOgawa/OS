CREATE DATABASE  IF NOT EXISTS `hiraya` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `hiraya`;
-- MySQL dump 10.13  Distrib 8.0.32, for Win64 (x86_64)
--
-- Host: localhost    Database: hiraya
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tbl_arenas`
--

DROP TABLE IF EXISTS `tbl_arenas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_arenas` (
  `arenaID` int NOT NULL AUTO_INCREMENT,
  `arenaName` varchar(45) DEFAULT NULL,
  `additionalDetails` varchar(45) DEFAULT NULL,
  `streamURL` varchar(45) DEFAULT NULL,
  `streamMimeType` varchar(45) DEFAULT NULL,
  `iosStreamURL` varchar(45) DEFAULT NULL,
  `status` varchar(45) DEFAULT NULL,
  `coverPhoto` blob,
  PRIMARY KEY (`arenaID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_arenas`
--

LOCK TABLES `tbl_arenas` WRITE;
/*!40000 ALTER TABLE `tbl_arenas` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_arenas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_battle_histories`
--

DROP TABLE IF EXISTS `tbl_battle_histories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_battle_histories` (
  `battleHistoryID` int NOT NULL,
  `fightNumber` int DEFAULT NULL,
  `meron` decimal(10,0) DEFAULT NULL,
  `wala` decimal(10,0) DEFAULT NULL,
  `draw` decimal(10,0) DEFAULT NULL,
  `netPay` decimal(10,0) DEFAULT NULL,
  `payOut` decimal(10,0) DEFAULT NULL,
  `adminCom` decimal(10,0) DEFAULT NULL,
  `subOperatorCom` decimal(10,0) DEFAULT NULL,
  `masterCom` decimal(10,0) DEFAULT NULL,
  `goldCom` decimal(10,0) DEFAULT NULL,
  `totalCom` decimal(10,0) DEFAULT NULL,
  `detail` varchar(100) DEFAULT NULL,
  `status` varchar(45) DEFAULT NULL,
  `battleCode` varchar(45) DEFAULT NULL,
  `closeAt` varchar(45) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  PRIMARY KEY (`battleHistoryID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_battle_histories`
--

LOCK TABLES `tbl_battle_histories` WRITE;
/*!40000 ALTER TABLE `tbl_battle_histories` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_battle_histories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_bet_histories`
--

DROP TABLE IF EXISTS `tbl_bet_histories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_bet_histories` (
  `betHistoryID` int NOT NULL AUTO_INCREMENT,
  `fightNumber` int DEFAULT NULL,
  `username` varchar(45) DEFAULT NULL,
  `betAmount` decimal(10,0) DEFAULT NULL,
  `availableWallet` decimal(10,0) DEFAULT NULL,
  `remainingWallet` decimal(10,0) DEFAULT NULL,
  `netPay` decimal(10,0) DEFAULT NULL,
  `betTo` varchar(45) DEFAULT NULL,
  `status` varchar(45) DEFAULT NULL,
  `flag` varchar(45) DEFAULT NULL,
  `battleClosedAt` datetime DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  PRIMARY KEY (`betHistoryID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_bet_histories`
--

LOCK TABLES `tbl_bet_histories` WRITE;
/*!40000 ALTER TABLE `tbl_bet_histories` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_bet_histories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_bets`
--

DROP TABLE IF EXISTS `tbl_bets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_bets` (
  `betID` int NOT NULL AUTO_INCREMENT,
  `battleHistoryID` int DEFAULT NULL,
  `fightNumber` int DEFAULT NULL,
  `userID` int DEFAULT NULL,
  `userName` varchar(45) DEFAULT NULL,
  `availableWallet` decimal(10,0) DEFAULT NULL,
  `isDummy` varchar(45) DEFAULT NULL,
  `betTo` varchar(45) DEFAULT NULL,
  `betAmount` decimal(10,0) DEFAULT NULL,
  `admin` decimal(10,0) DEFAULT NULL,
  `operator` decimal(10,0) DEFAULT NULL,
  `subOperator` decimal(10,0) DEFAULT NULL,
  `master` decimal(10,0) DEFAULT NULL,
  `gold` decimal(10,0) DEFAULT NULL,
  `payOut` decimal(10,0) DEFAULT NULL,
  `netPay` decimal(10,0) DEFAULT NULL,
  PRIMARY KEY (`betID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_bets`
--

LOCK TABLES `tbl_bets` WRITE;
/*!40000 ALTER TABLE `tbl_bets` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_bets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_registration_code`
--

DROP TABLE IF EXISTS `tbl_registration_code`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_registration_code` (
  `registrationCodeID` int NOT NULL AUTO_INCREMENT,
  `code` varchar(100) DEFAULT NULL,
  `maxUsage` int DEFAULT NULL,
  `remainingCode` int DEFAULT NULL,
  `dataCreated` datetime DEFAULT NULL,
  PRIMARY KEY (`registrationCodeID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_registration_code`
--

LOCK TABLES `tbl_registration_code` WRITE;
/*!40000 ALTER TABLE `tbl_registration_code` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_registration_code` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_role_management`
--

DROP TABLE IF EXISTS `tbl_role_management`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_role_management` (
  `roleManagementID` int NOT NULL,
  `name` varchar(45) DEFAULT NULL,
  `slug` varchar(45) DEFAULT NULL,
  `commisionPercent` decimal(10,0) DEFAULT NULL,
  `description` varchar(100) DEFAULT NULL,
  `isPublic` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`roleManagementID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_role_management`
--

LOCK TABLES `tbl_role_management` WRITE;
/*!40000 ALTER TABLE `tbl_role_management` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_role_management` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_support_ticket`
--

DROP TABLE IF EXISTS `tbl_support_ticket`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_support_ticket` (
  `ticketID` int NOT NULL AUTO_INCREMENT,
  `reason` varchar(100) DEFAULT NULL,
  `subjectTitle` varchar(45) DEFAULT NULL,
  `url` varchar(100) DEFAULT NULL,
  `description` varchar(45) DEFAULT NULL,
  `attachment` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`ticketID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_support_ticket`
--

LOCK TABLES `tbl_support_ticket` WRITE;
/*!40000 ALTER TABLE `tbl_support_ticket` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_support_ticket` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_transactioncashinout`
--

DROP TABLE IF EXISTS `tbl_transactioncashinout`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_transactioncashinout` (
  `transactionID` int NOT NULL AUTO_INCREMENT,
  `operator` varchar(45) DEFAULT NULL,
  `type` varchar(45) DEFAULT NULL,
  `ref` varchar(45) DEFAULT NULL,
  `to` varchar(45) DEFAULT NULL,
  `requestedBy` varchar(45) DEFAULT NULL,
  `sponsorAgent` varchar(45) DEFAULT NULL,
  `amount` decimal(10,0) DEFAULT NULL,
  `availableWallet` decimal(10,0) DEFAULT NULL,
  `RemainingWallet` decimal(10,0) DEFAULT NULL,
  `availableComWallet` decimal(10,0) DEFAULT NULL,
  `agentCurrentWallet` decimal(10,0) DEFAULT NULL,
  `for` varchar(45) DEFAULT NULL,
  `status` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`transactionID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_transactioncashinout`
--

LOCK TABLES `tbl_transactioncashinout` WRITE;
/*!40000 ALTER TABLE `tbl_transactioncashinout` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_transactioncashinout` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_user_account`
--

DROP TABLE IF EXISTS `tbl_user_account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_user_account` (
  `userID` int NOT NULL AUTO_INCREMENT,
  `fullname` varchar(45) DEFAULT NULL,
  `birthday` varchar(45) DEFAULT NULL,
  `gender` varchar(45) DEFAULT NULL,
  `username` varchar(45) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `phoneNumber` varchar(45) DEFAULT NULL,
  `role` varchar(45) DEFAULT NULL,
  `status` varchar(45) DEFAULT NULL,
  `password` varchar(45) DEFAULT NULL,
  `accessLevel` varchar(45) DEFAULT NULL,
  `profilePhoto` blob,
  `country` varchar(45) DEFAULT NULL,
  `state` varchar(45) DEFAULT NULL,
  `city` varchar(45) DEFAULT NULL,
  `homeAddress` varchar(45) DEFAULT NULL,
  `postalCode` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`userID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_user_account`
--

LOCK TABLES `tbl_user_account` WRITE;
/*!40000 ALTER TABLE `tbl_user_account` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_user_account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_user_management`
--

DROP TABLE IF EXISTS `tbl_user_management`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_user_management` (
  `userID` int NOT NULL,
  `username` varchar(45) DEFAULT NULL,
  `sponsor` varchar(45) DEFAULT NULL,
  `role` varchar(45) DEFAULT NULL,
  `status` varchar(45) DEFAULT NULL,
  `comWallet` decimal(10,0) DEFAULT NULL,
  `wallet` decimal(10,0) DEFAULT NULL,
  `comPercent` decimal(10,0) DEFAULT NULL,
  `tbl_UserManagementcol` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`userID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_user_management`
--

LOCK TABLES `tbl_user_management` WRITE;
/*!40000 ALTER TABLE `tbl_user_management` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_user_management` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'hiraya'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-03-31  9:01:45
