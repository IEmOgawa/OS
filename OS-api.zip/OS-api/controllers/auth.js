const mysql = require("mysql");

//DATABASE Connection
const db = mysql.createConnection({
    host: process.env.HOST,
    user: process.env.USER,
    password: process.env.PASSWORD,
    database: process.env.DB
});

//add new user/ Register
exports.register = (req, res) => {
    const {
        Fullname,
        Birthday,
        Gender,
        Username,
        Email,
        PhoneNumber,
        Role,
        Status,
        Password,
        Retypepassword,
        AccessLevel,
        Country
      } = req.body;

      db.query("SELECT username FROM tbl_user_account where username = ?", [Username], async (error, results) => {
        if (error) {
            console.log(error);
        } 
        if (results.length > 0) {           
            return res.send({message: "Username already exist"})
        } else if ( Password !== Retypepassword) {
            return res.send({message: "Password does not match"})
        }


        db.query("INSERT INTO tbl_user_account SET ?", 
        {
        fullname: Fullname,
        birthday: Birthday,
        gender: Gender,
        username: Username,
        email: Email,
        phoneNumber: PhoneNumber,
        role: Role,
        status: Status,
        password: Password,
        accessLevel: AccessLevel,
        country: Country        
        },
        (error,results) => {
            if(error) {
                console.log(error);
                return res.send({message: "Enter correct asked details"})
            } else {
                console.log(results)
                res.send(results);
            }
        });
      });
}

exports.login = (req, res) => {
    const {
        Username,
        Password
      } = req.body;

      db.query("SELECT * FROM tbl_users where col_userName = ? AND col_password = ?", [Username, Password],
      (error, results) => {
        if (error) {
            console.log(error);Password
            req.setEncoding({error: error})
        }else{
            if (results.length > 0) {
                res.send(results);
              } else{
                  return res.send({message: "Wrong username or password"})
              }
        }      

      });
}

//add new arena/ Arena
exports.register = (req, res) => {
    const {
        ArenaName,
        AdditionalDetails,
        StreamURL,
        StreamMimeType,
        IosStreamURL,
        Status
      } = req.body;

      db.query("SELECT username FROM tbl_arenas where arenaName = ?", [ArenaName], async (error, results) => {
        if (error) {
            console.log(error);
        } 
        if (results.length > 0) {           
            return res.send({message: "arenaName already exist"})
        }

        db.query("INSERT INTO tbl_arenas SET ?", 
        {
            arenaName: ArenaName,
            additionalDetails: AdditionalDetails,
            streamURL: StreamURL,
            streamMimeType : StreamMimeType,
            iosStreamURL: IosStreamURL,
            status: Status
        },
        (error,results) => {
            if(error) {
                console.log(error);
                return res.send({message: "Enter correct asked details"})
            } else {
                console.log(results)
                res.send(results);
            }
        });
      });
}
