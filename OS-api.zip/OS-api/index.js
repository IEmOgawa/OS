const express = require("express");
const path = require("path");
const mysql = require("mysql");
const cors = require("cors");
const dotenv = require("dotenv");

//secure location -----------------------------------------
dotenv.config({
    path: './.env'
});

const app = express();
app.use(cors());
// Parse URL-encoded bodies (as sent by HTML forms)
app.use(express.urlencoded ({
    extended: false
}));  
// Parse JSON bodies (as sent by API clients)---------------------------
app.use(express.json());

//----------------------------------------------
const publicDirectory = path.join(__dirname, "./public");
app.use(express.static(publicDirectory));

//Define routes----------------------------------------------------
app.use("/", require("./routes/pages"));
app.use("/auth", require("./routes/auth"));

app.listen(7070, () => {
    console.log("Server started on Port 7070");  
  });